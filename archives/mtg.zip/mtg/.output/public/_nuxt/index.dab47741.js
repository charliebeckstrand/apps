import{_ as e,l as c,k as n}from"./entry.891440b4.js";const r={};function t(o,s){return n(),c("div")}const a=e(r,[["render",t]]);export{a as default};
