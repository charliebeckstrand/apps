const client_manifest = {
  "../../node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.9e3446f3.css",
    "src": "../../node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "../../node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "error-404.9e3446f3.css"
    ],
    "file": "error-404.32f4abd0.js",
    "imports": [
      "../../node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "../../node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.9e3446f3.css": {
    "file": "error-404.9e3446f3.css",
    "resourceType": "style"
  },
  "../../node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.efd96ca4.css",
    "src": "../../node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "../../node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "error-500.efd96ca4.css"
    ],
    "file": "error-500.f84f9dc1.js",
    "imports": [
      "../../node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "../../node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.efd96ca4.css": {
    "file": "error-500.efd96ca4.css",
    "resourceType": "style"
  },
  "../../node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.b7db9c59.css",
    "src": "../../node_modules/nuxt/dist/app/entry.css"
  },
  "../../node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "entry.b7db9c59.css"
    ],
    "dynamicImports": [
      "layouts/default.vue",
      "../../node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "../../node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "entry.891440b4.js",
    "isEntry": true,
    "src": "../../node_modules/nuxt/dist/app/entry.js"
  },
  "entry.b7db9c59.css": {
    "file": "entry.b7db9c59.css",
    "resourceType": "style"
  },
  "_Card.vue.8b9f4e77.js": {
    "resourceType": "script",
    "module": true,
    "file": "Card.vue.8b9f4e77.js",
    "imports": [
      "../../node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "file": "default.f5e3b4f2.js",
    "imports": [
      "../../node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "pages/draft.css": {
    "resourceType": "style",
    "file": "draft.5b41a747.css",
    "src": "pages/draft.css"
  },
  "pages/draft.vue": {
    "resourceType": "script",
    "module": true,
    "css": [
      "draft.5b41a747.css"
    ],
    "file": "draft.aa339669.js",
    "imports": [
      "../../node_modules/nuxt/dist/app/entry.js",
      "_Card.vue.8b9f4e77.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/draft.vue"
  },
  "draft.5b41a747.css": {
    "file": "draft.5b41a747.css",
    "resourceType": "style"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.33adf822.js",
    "imports": [
      "../../node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "pages/sealed/[set_code].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_set_code_.7438927a.js",
    "imports": [
      "_Card.vue.8b9f4e77.js",
      "../../node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/sealed/[set_code].vue"
  },
  "pages/sealed/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.dab47741.js",
    "imports": [
      "../../node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/sealed/index.vue"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
