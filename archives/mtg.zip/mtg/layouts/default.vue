<template>
	<div class="bg-primary min-h-full">
		<slot />
	</div>
</template>
