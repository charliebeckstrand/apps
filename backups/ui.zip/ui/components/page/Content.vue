<script setup lang="ts"></script>

<template>
	<div class="ui-page-content space-y-4 p-4">
		<slot />
	</div>
</template>
