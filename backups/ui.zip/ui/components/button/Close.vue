<script setup lang="ts">
import { XMarkIcon } from '@heroicons/vue/24/outline'
</script>

<template>
	<UIButton aria-label="Close">
		<UIIcon :icon="XMarkIcon" />
	</UIButton>
</template>
