type Sort = 'asc' | 'desc' | 'none'

export type { Sort }
