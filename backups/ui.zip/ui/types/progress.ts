import type { Color } from './base/color'
import type { Size } from './base/size'

export type { Color, Size }
