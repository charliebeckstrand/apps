export type Size = 'sm' | 'md' | 'lg'
