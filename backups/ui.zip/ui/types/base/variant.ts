export type Variant = 'default' | 'outlined' | 'tonal' | 'plain'
