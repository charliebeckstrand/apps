export type Density = 'default' | 'comfortable' | 'compact'
