export type Padding = 'sm' | 'md' | 'lg' | 'none'
