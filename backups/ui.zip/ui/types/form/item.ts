import type { Variant } from '@/types/base/variant'

export type { Variant }
