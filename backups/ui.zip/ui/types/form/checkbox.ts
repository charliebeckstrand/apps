import type { Color } from '@/types/base/color'
import type { Size } from '@/types/base/size'

export type { Color, Size }
