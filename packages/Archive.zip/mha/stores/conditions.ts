import { defineStore } from 'pinia'

import type { Condition } from '@/types/condition'

export const useConditionsStore = defineStore('conditions', {
	state: () => ({
		conditions: [] as Condition[]
	}),
	actions: {
		addCondition(condition: Condition) {
			this.conditions.push(condition)
		}
	}
})
