import { defineStore } from 'pinia'

import type { Tag } from '@/types/tag'

export const useTagsStore = defineStore('tags', {
	state: () => ({
		tags: [] as Tag[]
	}),
	actions: {
		setTags(tags: Tag[]) {
			this.tags = tags
		}
	}
})
