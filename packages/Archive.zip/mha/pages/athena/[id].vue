<script setup lang="ts"></script>

<template>
	<Athena />
</template>
