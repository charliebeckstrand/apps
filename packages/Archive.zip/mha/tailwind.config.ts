module.exports = {
	theme: {
		extend: {
			colors: {
				primary: '#393646',
				secondary: '#4F4557',
				accent: '#6D5D6E',

				success: '#4CAF50',
				warning: '#F8B500',
				danger: '#FC3C3C'
			}
		}
	},
	darkMode: 'media',
	presets: ['../../tailwind.config']
}
