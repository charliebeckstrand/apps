<template>
	<div class="flex h-full min-h-full overflow-hidden">
		<AthenaSidebar />

		<div class="flex-grow bg-[#bbb]">
			<AthenaPdfViewer />
		</div>
	</div>
</template>
