<script setup lang="ts">
import { Bars3Icon } from '@heroicons/vue/24/outline'
</script>

<template>
	<div class="flex h-full flex-col">
		<UINavbar color="dark">
			<template #left>
				<UIButton
					icon
					dark
				>
					<UIIcon :icon="Bars3Icon" />
				</UIButton>
			</template>
		</UINavbar>
		<div class="background-[#d7d7d7] overflow-y-auto p-4"></div>
	</div>
</template>
