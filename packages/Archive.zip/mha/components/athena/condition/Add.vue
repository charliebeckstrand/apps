<script setup lang="ts">
import { useVuelidate } from '@vuelidate/core'
import { required, helpers } from '@vuelidate/validators'

import { CalendarIcon, XMarkIcon } from '@heroicons/vue/24/outline'

import { useTagsStore } from '@/stores/tags'

import type { Condition } from '@/types/condition'

type Emit = {
	(event: 'update:modelValue', value: Condition): void
	(event: 'add', value: Condition): void
	(event: 'cancel'): void
}

type Props = {
	condition: Condition
}

const emit = defineEmits<Emit>()

const props = withDefaults(defineProps<Props>(), {
	condition: undefined
})

const tagsStore = useTagsStore()

tagsStore.setTags([
	{
		name: 'Tag 1'
	},
	{
		name: 'Tag 2'
	},
	{
		name: 'Tag 3'
	}
])

const tags = computed(() => tagsStore.tags.map((tag) => tag.name))

const editableCondition = computed({
	get: () => {
		const condition = props.condition ? (props.condition as Condition) : ({} as Condition)

		return condition
	},
	set: (newValue) => {
		emit('update:modelValue', newValue)
	}
})

const rules = computed(() => ({
	name: {
		required: helpers.withMessage('Condition name is required', required)
	},
	occurences: {
		required: helpers.withMessage('At least one occurence is required', required)
	},
	chronicity: {
		required: helpers.withMessage('Required', required)
	}
}))

const v$ = useVuelidate(rules, editableCondition.value)

const cancel = () => {
	emit('cancel')
}

const add = async () => {
	const valid = await v$.value.$validate()

	if (!valid) {
		return
	}

	emit('add', editableCondition.value)
}

const currentOccurence = ref('')

const addOccurence = (date: string) => {
	editableCondition.value.occurences = editableCondition.value.occurences || []

	editableCondition.value.occurences.push(date)

	currentOccurence.value = ''
}
</script>
<template>
	<UICard variant="outlined">
		<div class="flex flex-col space-y-2">
			<UIFormGroup
				orientation="horizontal"
				:validation="v$.name"
			>
				<UIFormLabel :for="`condition-${props.condition.id}-name`">Condition:</UIFormLabel>
				<UIFormInput
					:id="`condition-${props.condition.id}-name`"
					v-model="editableCondition.name"
					placeholder="Condition Name"
					variant="outlined"
					size="sm"
				/>
			</UIFormGroup>

			<UIFormGroup
				orientation="horizontal"
				:validation="v$.occurences"
			>
				<UILabel>Occurences:</UILabel>
				<UIDatepicker
					:id="`condition-${props.condition.id}-occurences`"
					v-model="currentOccurence"
					@update:modelValue="addOccurence"
				>
					<template #trigger>
						<UIButton
							color="primary"
							variant="tonal"
							size="sm"
						>
							<template #prepend>
								<UIIcon
									:icon="CalendarIcon"
									size="sm"
								/>
							</template>
							Add
						</UIButton>
					</template>
				</UIDatepicker>
			</UIFormGroup>

			<div
				v-if="editableCondition.occurences.length"
				class="flex items-center space-x-2 overflow-x-auto"
			>
				<UIBadge
					v-for="(occurence, index) in editableCondition.occurences"
					:key="index"
					color="primary"
					variant="tonal"
				>
					{{ occurence }}
					<template #append>
						<UIIcon
							:icon="XMarkIcon"
							size="xs"
							class="cursor-pointer"
							@click="editableCondition.occurences.splice(index, 1)"
						/>
					</template>
				</UIBadge>
			</div>

			<div class="flex space-x-2">
				<UIFormGroup :validation="v$.chronicity">
					<UIFormLabel
						:for="`condition-${props.condition.id}-chronicity`"
						class="hidden"
					>
						Chronicity:
					</UIFormLabel>
					<UICombobox
						:id="`condition-${props.condition.id}-chronicity`"
						v-model="editableCondition.chronicity"
						:items="['Temporary', 'Permanent']"
						placeholder="Chronicity"
						variant="outlined"
						size="sm"
					/>
				</UIFormGroup>

				<UIFormGroup>
					<UIFormLabel
						:for="`condition-${props.condition.id}-tags`"
						class="hidden"
					>
						Tags:
					</UIFormLabel>
					<UICombobox
						:id="`condition-${props.condition.id}-tags`"
						v-model="editableCondition.tags"
						:items="tags"
						placeholder="Tags"
						multiple
						variant="outlined"
						size="sm"
					/>
				</UIFormGroup>
			</div>

			<UIFormGroup>
				<UIFormLabel
					:for="`condition-${props.condition.id}-notes`"
					class="hidden"
				>
					Notes:
				</UIFormLabel>
				<UIFormTextarea
					:id="`condition-${props.condition.id}-notes`"
					v-model="editableCondition.notes"
					placeholder="Notes"
					variant="outlined"
					size="sm"
				/>
			</UIFormGroup>
		</div>

		<template #append>
			<div class="flex items-center justify-end space-x-2">
				<UIButton
					color="primary"
					variant="outlined"
					size="sm"
					@click="cancel"
				>
					Cancel
				</UIButton>
				<UIButton
					color="primary"
					size="sm"
					@click="add"
				>
					Add
				</UIButton>
			</div>
		</template>
	</UICard>
</template>
