<script setup lang="ts">
import { useConditionsStore } from '@/stores/conditions'

import type { Condition } from '@/types/condition'

type Props = {
	condition: Condition
}

const props = withDefaults(defineProps<Props>(), {
	condition: undefined
})

const conditionsStore = useConditionsStore()
</script>
<template>
	<UICard variant="outlined">
		{{ props.condition }}
	</UICard>
</template>
