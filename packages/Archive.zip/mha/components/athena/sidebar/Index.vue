<script setup lang="ts">
import { PlusIcon } from '@heroicons/vue/24/outline'

import { useConditionsStore } from '@/stores/conditions'

import type { Condition } from '@/types/condition'

type State = {
	startDate: string
	endDate: string
}

const state: State = reactive({
	startDate: '01/01/2021',
	endDate: '01/31/2021'
})

const conditionsStore = useConditionsStore()

const conditions = computed(() => conditionsStore.conditions)

const condition = ref({} as Condition)
const addingCondition = ref(false)

const newCondition = () => {
	addingCondition.value = true

	const randomId = Math.random().toString(36).substr(2, 9)

	const newCondition: Condition = {
		id: randomId,
		name: '',
		occurences: [],
		chronicity: 'Permanent',
		tags: [],
		notes: ''
	}

	condition.value = newCondition
}

const addNewCondition = (condition: Condition) => {
	if (condition?.id) {
		conditionsStore.addCondition(condition)

		addingCondition.value = false
	}
}

const cancelNewCondition = () => {
	addingCondition.value = false
}

onBeforeUnmount(() => {
	addingCondition.value = false
})
</script>
<template>
	<UISidebar
		color="gray"
		class="border-r"
		width="360px"
	>
		<template #prepend>
			<UIHeader
				size="lg"
				weight="bold"
				class="h-[5rem] min-h-[5rem]"
			>
				<template #title>Medical Conditions</template>
				<template #subtitle>{{ state.startDate }} - {{ state.endDate }}</template>
				<template #append>
					<UIButton
						color="primary"
						icon
						size="sm"
						:disabled="addingCondition"
						@click="newCondition"
					>
						<UIIcon
							:icon="PlusIcon"
							size="sm"
						/>
					</UIButton>
				</template>
			</UIHeader>
		</template>

		<template #default>
			<div class="h-full space-y-2 overflow-y-auto">
				<template v-if="addingCondition">
					<AthenaConditionAdd
						:condition="condition"
						@add="addNewCondition"
						@cancel="cancelNewCondition"
					/>
				</template>
				<template v-if="conditions?.length">
					<AthenaCondition
						v-for="(condition, index) in conditions"
						:key="index"
						:condition="condition"
					>
						{{ condition.name }}
					</AthenaCondition>
				</template>
				<template v-else-if="!conditions.length && !addingCondition">
					<UIAlert
						color="warning"
						variant="tonal"
					>
						No conditions found.
					</UIAlert>
				</template>
			</div>
		</template>
	</UISidebar>
</template>
