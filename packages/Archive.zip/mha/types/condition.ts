type Condition = {
	id: string
	name: string | undefined
	occurences: string[]
	chronicity: string | undefined
	tags?: string[]
	notes?: string
}

export type { Condition }
