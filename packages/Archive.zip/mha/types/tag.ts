type Tag = {
	name: string
}

export type { Tag }
