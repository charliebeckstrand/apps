<template>
	<NuxtLayout />
</template>
