<template>
	<NuxtPage />
</template>
