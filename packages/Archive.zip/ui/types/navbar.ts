type Variant = 'default'
type Color = 'primary' | 'secondary' | 'transparent' | 'dark'

export type { Color, Variant }
