export type BorderRadius = 'sm' | 'md' | 'lg' | 'full' | 'none'
