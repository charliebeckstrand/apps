type Size = 'xs' | 'sm' | 'md' | 'lg'

export type { Size }
