import type { Color } from './color'
import type { Size } from './size'
import type { Variant } from './variant'

export type { Color, Size, Variant }
