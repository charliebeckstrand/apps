type Resize = 'none' | 'vertical' | 'horizontal' | 'both'
type Size = 'xs' | 'sm' | 'md' | 'lg'
type Variant = 'default' | 'outlined'

export type { Resize, Size, Variant }
